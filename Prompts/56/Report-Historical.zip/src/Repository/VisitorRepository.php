<?php

namespace App\Repository;

use App\Entity\Patient;
use App\Entity\Visitor;
use Doctrine\Bundle\DoctrineBundle\Repository\ServiceEntityRepository;
use Doctrine\ORM\Query;
use Doctrine\Persistence\ManagerRegistry;

/**
 * @extends ServiceEntityRepository<Visitor>
 */
class VisitorRepository extends ServiceEntityRepository
{
    public function __construct(ManagerRegistry $registry)
    {
        parent::__construct($registry, Visitor::class);
    }

    /**
     * @return Visitor[]
     */
    public function findTodaysVisitorsByPatient(Patient $patient): array
    {
        $todayStart = new \DateTime('today');
        $todayEnd = new \DateTime('tomorrow');

        return $this->createQueryBuilder('v')
		    ->innerJoin('v.patient', 'p')
		    ->andWhere('p.id = :patientId')
		    ->andWhere('v.checkInAt >= :todayStart')
		    ->andWhere('v.checkInAt < :todayEnd')
		    ->orderBy('v.checkInAt', 'ASC')
		    ->setParameter('patientId', $patient->getId())
		    ->setParameter('todayStart', $todayStart)
		    ->setParameter('todayEnd', $todayEnd)
		    ->orderBy('v.checkInAt', 'DESC')
		    ->getQuery()
		    ->getResult();
    }

    public function findOneByTag(int $tag): ?Visitor
    {
        return $this->createQueryBuilder('v')
		    ->andWhere('v.tag = :tag')
		    ->andWhere('v.checkInAt IS NOT NULL')
		    ->andWhere('v.checkOutAt IS NULL')
		    ->setParameter('tag', $tag)
		    ->getQuery()
		    ->getOneOrNullResult();
    }

    /**
     * @param string $name
     * @return Visitor[]
     */
    public function findByName(string $name): array
    {
        return $this->createQueryBuilder('v')
		    ->andWhere('LOWER(v.name) LIKE LOWER(:name)')
		    ->setParameter('name', '%' . str_replace(' ', '%', $name) . '%')
		    ->orderBy('v.name', 'ASC')
		    ->getQuery()
		    ->getResult();
    }

    /**
     * @return Query
     */
    public function paginateVisitor(string $filter = null): Query
    {
        $query = $this->createQueryBuilder('v')
		      ->orderBy('v.id', 'ASC');

        if ($filter) {
            $query->andWhere('v.name LIKE :filter OR v.tag LIKE :filter')
                  ->setParameter('filter', '%' . $filter . '%');
        }

        return $query->getQuery();
    }

    /**
     * @return array
     */
    public function findAllCheckTimes(): array
    {
        return $this->getEntityManager()->createQuery(
            'SELECT v.checkInAt, v.checkOutAt FROM App\Entity\Visitor v'
        )->getResult();
    }

    /**
     * @return array
     */
    public function findTodayCheckTimes(): array
    {
        $today = new \DateTime('today midnight');
        $tomorrow = new \DateTime('tomorrow midnight');

        return $this->getEntityManager()->createQuery(
            'SELECT v.checkInAt, v.checkOutAt FROM App\Entity\Visitor v
             WHERE v.checkInAt < :tomorrow AND (v.checkOutAt IS NULL OR v.checkOutAt >= :today)'
        )
        ->setParameter('today', $today)
        ->setParameter('tomorrow', $tomorrow)
        ->getResult();
    }
}
