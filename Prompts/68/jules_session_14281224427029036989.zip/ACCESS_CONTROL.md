# Control de Acceso de Usuarios Implementado

Este documento detalla la jerarquía de roles y la matriz de permisos de control de acceso que está implementada actualmente a nivel de controladores en la aplicación.

## Jerarquía de Roles

Las funciones de los usuarios se basan en la configuración de la jerarquía de roles en Symfony (`config/packages/security.yaml`):

```yaml
role_hierarchy:
    ROLE_ADMIN:       ROLE_USER
    ROLE_SUPER_ADMIN: [ROLE_ADMIN]
```

Cualquier usuario con un rol superior hereda todos los permisos de los roles inferiores.

---

## Matriz de Permisos Implementada

A continuación se describe el control de acceso real implementado en cada método de los controladores:

| Acción                         | Patient / Hospitalized | Appointment      | Attendance       | Visitor / Stakeholder | User                             | Area             | Employee         | Scheduled        |
| :---                           | :---                   | :---             | :---             | :---                  | :---                             | :---             | :---             | :---             |
| **index**                      | ROLE_USER              | ROLE_USER        | ROLE_USER        | ROLE_USER             | ROLE_ADMIN                       | ROLE_USER        | ROLE_USER        | ROLE_USER        |
| **show**                       | ROLE_USER              | ROLE_USER        | ROLE_USER        | ROLE_USER             | ROLE_ADMIN (o el mismo usuario)  | ROLE_USER        | ROLE_USER        | ROLE_USER        |
| **new / register**             | ROLE_SUPER_ADMIN       | ROLE_SUPER_ADMIN | ROLE_USER        | ROLE_USER             | ROLE_ADMIN                       | ROLE_ADMIN       | ROLE_ADMIN       | ROLE_ADMIN       |
| **edit**                       | ROLE_SUPER_ADMIN       | ROLE_SUPER_ADMIN | ROLE_USER        | ROLE_USER             | ROLE_ADMIN (o el mismo usuario)* | ROLE_ADMIN       | ROLE_USER        | ROLE_ADMIN       |
| **delete**                     | ROLE_SUPER_ADMIN       | ROLE_SUPER_ADMIN | ROLE_SUPER_ADMIN | ROLE_SUPER_ADMIN      | ROLE_SUPER_ADMIN                 | ROLE_SUPER_ADMIN | ROLE_SUPER_ADMIN | ROLE_SUPER_ADMIN |
| **import / preview / process** | N/A                    | N/A              | N/A              | N/A                   | N/A                              | N/A              | N/A              | ROLE_ADMIN       |

\* *Nota sobre `User` (`edit`): Un `ROLE_ADMIN` no puede editar usuarios con rol `ROLE_SUPER_ADMIN` a menos que posea `ROLE_SUPER_ADMIN`.*

---

## Diferencias encontradas con la tabla de referencia

1. **Patient / Hospitalized / Appointment (`new`, `edit`):**
   - En la referencia indicaba `ROLE_ADMIN`.
   - **Implementado:** Requiere explícitamente `ROLE_SUPER_ADMIN` (`$this->denyAccessUnlessGranted('ROLE_SUPER_ADMIN')`).

2. **Area / Employee / Scheduled (`show`):**
   - En la referencia indicaba `ROLE_ADMIN`.
   - **Implementado:** Todos los usuarios con `ROLE_USER` pueden ver los detalles (`show`).

3. **Employee (`edit`):**
   - En la referencia indicaba `ROLE_ADMIN`.
   - **Implementado:** Los usuarios con `ROLE_USER` pueden editar un empleado.

4. **User (`show`, `edit`):**
   - Un usuario normal (`ROLE_USER`) puede ver y editar su propio perfil (`getUser()->getId() === $user->getId()`), mientras que los demás perfiles requieren `ROLE_ADMIN`.
